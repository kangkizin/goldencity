//test.js

var $=jQuery;

	$(document).ready(function(){
		
	});