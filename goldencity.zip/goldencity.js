//goldencity.js		

	
		$(document).ready(function(){
			$(".nav>.restaurant").mouseenter(function(){
				$(".navbg, .nav>.restaurant>ul, .sam1").stop() .slideDown(); 
			});//mouseover
			$(".nav>.restaurant").mouseleave(function(){
				$(".navbg, .nav>.restaurant>ul").stop() .slideUp();
			});//mouseout
			
		});//document