//tablet.js

var $= jQuery;

	
	$(document).ready(function(){
			$(".barm").click(function(){
				$(".menu7, .black").show();
			});
			$(".x, .black").click(function(){
				$(".menu7, .black").fadeOut();
			});
		});//document